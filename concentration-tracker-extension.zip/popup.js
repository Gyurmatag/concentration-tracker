// Concentration Tracker Extension
class ConcentrationTracker {
  constructor() {
    this.startTime = null;
    this.timerInterval = null;
    this.isRunning = false;
    this.sessionData = [];
    this.currentSession = null;
    this.participantId = null;
    
    // Google Apps Script Web App URL
    this.googleScriptUrl = 'https://script.google.com/macros/s/AKfycbyun8IQ6DddKXOTd6vC9LzPvc3KbAuVY7ex9cRQTx_CSHqGWeigXFAIpP7ywXQvDJ31/exec';
    
    this.initializeElements();
    this.loadSessionCount();
    this.setupEventListeners();
    this.initializeParticipantId();
  }
  
  initializeElements() {
    this.timerDisplay = document.getElementById('timerDisplay');
    this.startBtn = document.getElementById('startBtn');
    this.stopBtn = document.getElementById('stopBtn');
    this.sendBtn = document.getElementById('sendBtn');
    this.infoBtn = document.getElementById('infoBtn');
    this.status = document.getElementById('status');
    this.sessionCount = document.getElementById('sessionCount');
    this.infoModal = document.getElementById('infoModal');
    this.closeInfo = document.getElementById('closeInfo');
  }
  
  setupEventListeners() {
    this.startBtn.addEventListener('click', () => this.startTimer());
    this.stopBtn.addEventListener('click', () => this.stopTimer());
    this.sendBtn.addEventListener('click', () => this.sendData());
    this.infoBtn.addEventListener('click', () => this.showInfo());
    this.closeInfo.addEventListener('click', () => this.hideInfo());
    
    // Close modal when clicking outside
    this.infoModal.addEventListener('click', (e) => {
      if (e.target === this.infoModal) {
        this.hideInfo();
      }
    });
    
    // Close modal with Escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.infoModal.style.display === 'block') {
        this.hideInfo();
      }
    });
  }
  
  startTimer() {
    if (this.isRunning) return;
    
    this.startTime = Date.now();
    this.isRunning = true;
    this.currentSession = {
      startTime: this.startTime,
      endTime: null,
      duration: 0
    };
    
    this.startBtn.disabled = true;
    this.stopBtn.disabled = false;
    this.status.textContent = 'Focus session active • Stay concentrated';
    
    // Update timer every second
    this.timerInterval = setInterval(() => {
      this.updateTimer();
    }, 1000);
    
    // Store running state
    chrome.storage.local.set({ isRunning: true, startTime: this.startTime });
  }
  
  stopTimer() {
    if (!this.isRunning) return;
    
    const endTime = Date.now();
    const duration = endTime - this.startTime;
    
    this.isRunning = false;
    this.currentSession.endTime = endTime;
    this.currentSession.duration = duration;
    
    // Add to session data
    this.sessionData.push({
      ...this.currentSession,
      date: new Date().toISOString().split('T')[0]
    });
    
    this.startBtn.disabled = false;
    this.stopBtn.disabled = true;
    this.sendBtn.disabled = false;
    this.status.textContent = `Session completed • Duration: ${this.formatTime(duration)}`;
    
    clearInterval(this.timerInterval);
    
    // Update session count
    this.updateSessionCount();
    
    // Store data
    this.saveSessionData();
    chrome.storage.local.remove(['isRunning', 'startTime']);
  }
  
  updateTimer() {
    if (!this.isRunning || !this.startTime) return;
    
    const elapsed = Date.now() - this.startTime;
    this.timerDisplay.textContent = this.formatTime(elapsed);
  }
  
  formatTime(milliseconds) {
    const totalSeconds = Math.floor(milliseconds / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  }
  
  // This method is now handled by the async sendData() method above
  
  calculateTotalTime() {
    const totalMs = this.sessionData.reduce((sum, session) => sum + session.duration, 0);
    return this.formatTime(totalMs);
  }
  
  showInfo() {
    this.infoModal.style.display = 'block';
  }
  
  hideInfo() {
    this.infoModal.style.display = 'none';
  }
  
  loadSessionCount() {
    chrome.storage.local.get(['sessionData'], (result) => {
      if (result.sessionData) {
        this.sessionData = result.sessionData;
        this.updateSessionCount();
      }
      
      // Check if timer was running when popup was closed
      chrome.storage.local.get(['isRunning', 'startTime'], (result) => {
        if (result.isRunning && result.startTime) {
          this.startTime = result.startTime;
          this.isRunning = true;
          this.startBtn.disabled = true;
          this.stopBtn.disabled = false;
          this.status.textContent = 'Focus session resumed • Timer continues';
          
          // Resume timer
          this.timerInterval = setInterval(() => {
            this.updateTimer();
          }, 1000);
        }
      });
    });
  }
  
  updateSessionCount() {
    const today = new Date().toISOString().split('T')[0];
    const todaySessions = this.sessionData.filter(session => session.date === today).length;
    this.sessionCount.textContent = `Sessions today: ${todaySessions}`;
  }
  
  saveSessionData() {
    chrome.storage.local.set({ sessionData: this.sessionData });
  }
  
  initializeParticipantId() {
    chrome.storage.local.get(['participantId'], (result) => {
      if (!result.participantId) {
        // Generate a unique participant ID
        this.participantId = 'user_' + Math.random().toString(36).substr(2, 9);
        chrome.storage.local.set({ participantId: this.participantId });
      } else {
        this.participantId = result.participantId;
      }
    });
  }
  
  async sendData() {
    if (this.sessionData.length === 0) {
      this.status.textContent = 'No data to send yet';
      return;
    }
    
    if (this.googleScriptUrl === 'YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE') {
      this.status.textContent = 'Google Apps Script URL not configured';
      alert('Please configure the Google Apps Script URL first!\n\nSee the setup instructions in the code.');
      return;
    }
    
    this.status.textContent = 'Sending data to research database...';
    this.sendBtn.disabled = true;
    this.sendBtn.textContent = 'Sending...';
    
    try {
      const response = await this.submitToGoogleSheets();
      
      if (response.success) {
        this.status.textContent = `Data sent successfully! ${this.sessionData.length} sessions submitted.`;
        this.sessionData = []; // Clear sent data
        this.saveSessionData();
        this.updateSessionCount();
        this.sendBtn.disabled = true;
        this.sendBtn.textContent = 'Data Sent ✓';
        
        // Reset button after 3 seconds
        setTimeout(() => {
          this.sendBtn.textContent = 'Send Data';
          this.sendBtn.disabled = false;
        }, 3000);
      } else {
        throw new Error(response.error || 'Unknown error occurred');
      }
    } catch (error) {
      console.error('Error sending data:', error);
      this.status.textContent = `Error: ${error.message}`;
      this.sendBtn.disabled = false;
      this.sendBtn.textContent = 'Send Data';
      
      // Show error details
      alert(`Failed to send data:\n\n${error.message}\n\nPlease check your internet connection and try again.`);
    }
  }
  
  async submitToGoogleSheets() {
    const dataToSend = {
      sessions: this.sessionData,
      participantId: this.participantId,
      browserInfo: navigator.userAgent,
      experimentVersion: '1.0',
      timestamp: new Date().toISOString()
    };
    
    // Use POST request with proper CORS handling
    const response = await fetch(this.googleScriptUrl, {
      method: 'POST',
      mode: 'cors',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(dataToSend)
    });
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    return await response.json();
  }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new ConcentrationTracker();
});
